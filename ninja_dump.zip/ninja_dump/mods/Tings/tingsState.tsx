export type TingsShape = {
    ting?: any
}

export const tingsState: TingsShape|null = null
