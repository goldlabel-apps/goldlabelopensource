import { 
  notify,
  store,
  setPwaKey,
} from "../../../goldlabel"
import {
  getHost,
} from "../"

export const startTing = (): any =>
  async (dispatch: any) => {
    try {
      const {tings} = store.getState()
      dispatch(setPwaKey({ key: "tings", value: {
        ...tings,
      }}))
      dispatch(getHost())
    } catch (e: any) {
      dispatch(notify("error", `startTing ${e.toString()}`))
    }
}