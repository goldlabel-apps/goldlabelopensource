export const backofficeState: any = {
    activeCollection: null,
    collectionSub: null,
    busSlug: null,
    confirming: false,
    addDoc: null,
    changeDoc: null,
    bus: {},
}
