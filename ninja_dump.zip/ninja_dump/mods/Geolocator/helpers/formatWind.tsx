export const formatWind = (windSpeed: number) => {
  return "Light breeze"
}