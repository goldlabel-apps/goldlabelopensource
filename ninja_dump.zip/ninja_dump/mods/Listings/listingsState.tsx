import {ListingsShape} from "../types"

export const listingsState: ListingsShape = {
    menuOpen: false,
    addListing: null,
    editListing: null,
}