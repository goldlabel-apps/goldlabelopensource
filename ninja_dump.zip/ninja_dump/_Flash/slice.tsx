import {createSlice, PayloadAction} from "@reduxjs/toolkit";
import {RootState} from "../featuresStore";
import {
  FlashSlice,
  FeaturesKeyValue,
} from "../features-types";

const initialState: FlashSlice = {
  flashInitted: false,
}

export const flashSlice = createSlice({
  name: 'flash',
  initialState,
  reducers: {
    setFlashKey: (state, action: PayloadAction<FeaturesKeyValue>) => {
      const { key, value } = action.payload;
      // @ts-ignore
      state[key] = value;
    },
  },
})

export const selectFlash = (state: RootState) => state.flash;
export const { setFlashKey } = flashSlice.actions; 
export default flashSlice.reducer;
