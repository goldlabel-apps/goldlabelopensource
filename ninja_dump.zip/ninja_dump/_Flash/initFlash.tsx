import { AppThunk } from "../../featuresStore";
import { 
  featuresStore,
  setFlashKey,
  setSharedKey, 
} from "../../../Features";

export const initFlash = (): AppThunk => async (dispatch: any) => {
  try {
    const flash = featuresStore.getState().flash;
    const {flashInitted} = flash;
    if (!flashInitted){
      dispatch(setFlashKey({ key: "flashInitted", value: true }));
    }
    console.log("flash was Initted")
  } catch (error: any) {
    dispatch(setSharedKey({ key: 'notification', value: {
      severity: "error",
      code: "Flash 101",
      message: error.toString()
    }}))
  }
};
