import React from "react";
import { 
    useTheme,
} from "@mui/material";

const LetterEx = (props: any) => {
    const {color} = props;
    const theme = useTheme();
    const c = color || theme.palette.primary.main;

    return (
        <svg {...props} viewBox="0 0 64 117">
            <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                <g transform="translate(0.420000, 0.000000)" fill={c} fillRule="nonzero">
                    <polygon points="52.33 89.19 48.98 116.43 0 116.43 3.33 89.19"></polygon>
                    <polygon points="57.92 43.74 39.89 58.01 54.19 74.18 54.19 74.21 5.13 74.12 14.28 0 63.27 0"></polygon>
                </g>
            </g>
        </svg>
    )
};

export default LetterEx;
