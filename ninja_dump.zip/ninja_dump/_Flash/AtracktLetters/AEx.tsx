import React from "react";
import { 
    useTheme,
} from "@mui/material";

const AEx = (props: any) => {
    const {color} = props;
    const theme = useTheme();
    const c = color || theme.palette.primary.main;

    return (
        <svg {...props} viewBox="0 0 512 512">
           <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                <g fillRule="nonzero">
                    <g transform="translate(69.000000, 143.000000)">
                        <path fill={c} d="M329.96349,112.103706 L364.694476,84.5272482 L375,0 L280.632157,0 L263.006907,143.236142 L357.50975,143.409873 L357.50975,143.351962 L329.96349,112.103706 Z M347.473292,225 L353.926231,172.358527 L259.539768,172.358527 L253.125,225 L347.473292,225 Z"></path>
                        <path fill={c} d="M198.328607,112.123321 L219.883521,95.0789873 L207.740396,0 L64.818531,0 L9.66367401,145.787001 L0,225 L94.7193749,225 L100.956147,172.726538 L127.564691,172.726538 L121.328854,225 L216.087917,225 L226.041667,143.371577 L198.348264,112.103706 L198.328607,112.123321 Z M131.805845,143.429487 L104.208853,143.429487 L117.281457,46.6504011 L142.902489,46.6504011 L131.805845,143.429487 Z"></path>
                    </g>
                </g>
            </g>
        </svg>
    )
};

export default AEx;
