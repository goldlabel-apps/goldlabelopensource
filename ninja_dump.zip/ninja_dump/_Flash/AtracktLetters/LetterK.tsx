import React from "react";
import { 
    useTheme,
} from "@mui/material";

const LetterK = (props: any) => {
    const {color} = props;
    const theme = useTheme();
    const c = color || theme.palette.primary.main;

    return (
        <svg {...props} viewBox="0 0 126 117">
            <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                <polygon fill={c} fillRule="nonzero" points="63.05 116.43 67.79 78.27 55.71 63.38 49.11 116.43 0.58 116.43 14.85 0 63.37 0 56.46 55.99 72.24 41.14 77.31 0 125.83 0 120.44 43.8 102.38 58.12 116.69 74.31 111.56 116.43"></polygon>
            </g>
        </svg>
    )
};

export default LetterK;
