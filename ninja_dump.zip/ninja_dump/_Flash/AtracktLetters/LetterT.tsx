import React from "react";
import { 
    useTheme,
} from "@mui/material";

const LetterT = (props: any) => {
    const {color} = props;
    const theme = useTheme();
    const c = color || theme.palette.primary.main;

    return (
        <svg {...props} viewBox="0 0 90 117">
            <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                <polygon fill={c} fillRule="nonzero" points="8.48 116.43 18.27 37.66 0.13 37.66 4.83 0 89.75 0 85.04 37.66 66.99 37.66 57.19 116.43"></polygon>
            </g>
        </svg>
    )
};

export default LetterT;
