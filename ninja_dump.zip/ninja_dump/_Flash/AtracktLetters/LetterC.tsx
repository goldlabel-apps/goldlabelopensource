import React from "react";
import { 
    useTheme,
} from "@mui/material";

const LetterC = (props: any) => {
    const {color} = props;
    const theme = useTheme();
    const c = color || theme.palette.primary.main;

    return (
        <svg {...props} viewBox="0 0 122 117">
               <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                    <path d="M19.62,116.43 C12.34,116.43 7.06,114.63 3.93,111.09 C0.77,107.51 -0.37,102 0.55,94.7 L9.3,23.07 C11.2,7.99 20.21,0 35.33,0 L102.16,0 C109.25,0 114.43,1.79 117.57,5.33 C120.76,8.93 121.93,14.46 121.03,21.75 L117.59,49.79 L68.69,49.79 L71.92,24.13 L58.15,24.13 L49.87,92.29 L63.63,92.29 L67.05,63.45 L115.96,63.45 L112.29,93.35 C110.96,103.87 105.4,116.42 86.46,116.42 L19.63,116.42 L19.62,116.43 Z" fill={c} fillRule="nonzero"></path>
                </g>
        </svg>
    )
};

export default LetterC;
