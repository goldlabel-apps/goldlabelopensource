import React from "react";
import { 
    useTheme,
} from "@mui/material";

const LetterR = (props: any) => {
    const {color} = props;
    const theme = useTheme();
    const c = color || theme.palette.primary.main;

    return (
        <svg {...props} viewBox="0 0 124 117">
            <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                <path d="M119.95,5.23 C116.87,1.76 111.68,0 104.52,0 L14.7,0 L0.42,116.43 L49.34,116.43 L55.95,63.63 L67.4,80.3 L63.08,116.43 L112,116.43 L117.12,74.72 L102.21,58.03 L108.74,54.9 C116.73,51.07 120.46,45.9 121.61,37.06 L123.4,21.77 C124.27,14.33 123.11,8.76 119.96,5.22 L119.95,5.23 Z M70.52,55.3 L56.77,55.3 L60.75,24.14 L74.5,24.14 L70.52,55.3 Z" fill={c} fillRule="nonzero"></path>
            </g>
        </svg>
    )
};

export default LetterR;
