import React from "react";
import { 
    useTheme,
} from "@mui/material";

const LetterA = (props: any) => {
    const {color} = props;
    const theme = useTheme();
    const c = color || theme.palette.primary.main;

    return (
        <svg {...props} viewBox="0 0 117 117">
           <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
                <path d="M102.41,58.02 L113.54,49.2 L107.27,0 L33.47,0 L4.99,75.44 L0,116.43 L48.91,116.43 L52.13,89.38 L65.87,89.38 L62.65,116.43 L111.58,116.43 L116.72,74.19 L102.42,58.01 L102.41,58.02 Z M68.06,74.22 L53.81,74.22 L60.56,24.14 L73.79,24.14 L68.06,74.22 Z" fill={c} fillRule="nonzero"></path>
            </g>
        </svg>
    )
};

export default LetterA;
