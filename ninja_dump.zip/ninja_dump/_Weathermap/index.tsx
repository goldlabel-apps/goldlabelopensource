import Weathermap from "./Weathermap"

import {weathermapState} from "./initialState"
import {setWeathermapKey} from "./redux/setWeathermapKey"
import {fetchStormglass} from "./redux/fetchStormglass"
import {patchStormglass} from "./redux/patchStormglass"
import {setHourIndex} from "./redux/setHourIndex"

import WeathermapBackoffice from "./components/WeathermapBackoffice"
import Param from "./components/Param"
import {Timeline} from "./components/Timeline"
import {Controls} from "./components/Controls"
import {MapMarker} from "./components/MapMarker"
import SimpleMap from "./components/SimpleMap"
import Wind from "./components/Wind"

import {useAllMapPoints} from "./hooks/useAllMapPoints"
import {useDives} from "./hooks/useDives"
import {useShops} from "./hooks/useShops"

export {
    Weathermap,
    WeathermapBackoffice,
    weathermapState,
    setWeathermapKey,
    fetchStormglass,
    patchStormglass,

    useAllMapPoints,
    useDives,
    useShops,
    
    Controls,
    setHourIndex,
    
    MapMarker,
    SimpleMap,
    Wind,
    Param,
    Timeline,
}
