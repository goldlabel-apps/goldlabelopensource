import {WeathermapShape} from "./types"
import {paramMeta} from "../Weathermap/paramMeta"

export const weathermapState: WeathermapShape = {
    fetching: false,
    fetched: false,
    timeFetched: null,
    stormglass: null,
    hourIndex: 0,
    paramMeta,
    meta: null,
}
