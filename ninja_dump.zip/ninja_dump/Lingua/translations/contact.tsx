export const contact: any = {
    CONTACT: {
        en: "Contact",
        mt: "Kuntatt",
        de: "Kontakt",
        cn: "接触",
        pi: "Contact",
    },
    SEND_MESSGAE: {
        en: "Send a message",
        mt: "Ibghat messagg",
        de: "Nachricht schicken",
        cn: "发送一个消息",
        pi: "Send a message",
    },
    GET_IN_TOUCH: {
        en: "Get in touch",
        mt: "Ikkuntattjani",
        de: "In Kontakt kommen",
        cn: "保持联系",
        pi: "Get in touch",
    },
}
