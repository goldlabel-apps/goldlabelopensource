export const other: any = {
    GITHUB: {
        en: "Open Source",
        mt: "Sors miftuh",
        de: "Open Source",
        cn: "开源",
        it: "Open Source",
        pi: "FREE, you say?",
    },
    QUESTIONS: {
        en: "Questions",
        mt: "Mistoqsijiet",
        de: "Fragen",
        cn: "问题",
        pi: "Riddles",
    },
    ABOUT: {
        en: "About",
        mt: "Dwar",
        de: "Über",
        cn: "关于",
        pi: "About",
    },
}
