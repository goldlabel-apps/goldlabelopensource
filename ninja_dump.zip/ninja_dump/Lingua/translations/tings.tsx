export const tings: any = {
    ABOUT_YOU: {
        en: "About you",
        mt: "Dwarek",
        de: "Über dich",
        cn: "关于你",
        it: "About you",
        pi: "About you",
    },
    TINGS: {
        en: "Tings",
        mt: "Tings",
        de: "Tings",
        cn: "Tings",
        it: "Tings",
        pi: "Tings",
    },
    WHAT_IS_FINGERPRINT: {
        en: "A fingerprint is a unique id that is generated based on various attributes and characteristics of a user's device or browser",
        mt: "FINGERPRINT",
        de: "FINGERPRINT",
        cn: "FINGERPRINT",
        it: "FINGERPRINT",
        pi: "FINGERPRINT",
    },
    WHAT_ARE_TINGS: {
        en: "Whenever you visit an app or website your request carries with it some information like the IP adress it was requested from. Of course you can use a Virtual Private Network to improve your privacy and we recommend you do. Here is what we currenty have on file for you",
        mt: "request",
        de: "request",
        cn: "request",
        it: "request",
        pi: "request",
    },
}
